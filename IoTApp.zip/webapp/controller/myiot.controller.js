/*eslint-disable no-console, no-alert,sap-no-hardcoded-url */ 
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("IoTApp.controller.myiot", {
	
	onInit: function() {
    //   var oModel = new sap.ui.model.odata.v4.ODataModel({serviceUrl:"https://networkdbc5251932trial.hanatrial.ondemand.com/iotdata/iotservice.xsodata/",groupId:"$direct",synchronizationMode:"None"});
       
 //     var oModel = new sap.ui.model.json.JSONModel("https://iotmmsc5251932trial.hanatrial.ondemand.com/com.sap.iotservices.mms/v1/api/http/app.svc/T_IOT_MESSAGEFROMDEVICE?$format=json");
    //   var oModel = new sap.ui.model.odata.v2.ODataModel({serviceUrl:"https://networkdbc5251932trial.hanatrial.ondemand.com/iotdata/iotservice.xsodata/", json:true, useBatch:false});
      
        var oModel = new sap.ui.model.odata.ODataModel({serviceUrl:"/com.sap.iotservices.mms/v1/api/http/app.svc/", json:true, useBatch:false});
      
      this.getView().setModel(oModel);
       
	}
	});
});